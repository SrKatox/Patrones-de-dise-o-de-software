package EjercicioMochila;

public class Mochila {
    private double peso;
    
    public void setPeso(double peso) {
        this.peso = peso;
    }

    public double getPeso() {
        return peso;
    }
}
